﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tour_2040.Utils;

namespace Tour_2040.Models
{
    public class DanhGiaTour
    {
        public DanhGiaTour()
        {
            // Tự động sinh mã đánh giá: MDG + 6 số
            this.MaDanhGia = MaSoHelper.TaoMa("MDG");
            this.NgayDanhGia = DateTime.Now;
            this.NgayTao = DateTime.Now;
        }

        [Key]
        [Required, StringLength(50)]
        [Display(Name = "Mã đánh giá")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string MaDanhGia { get; set; }

        [Required]
        [StringLength(20)] // [ĐÃ SỬA] Từ 50 -> 20 để khớp với MaLichTrinh
        [Display(Name = "Mã lịch trình")]
        public string LichTrinhId { get; set; } = string.Empty;

        [ForeignKey("LichTrinhId")]
        public virtual LichTrinh? LichTrinh { get; set; }

        [StringLength(20)] // Cái này đã đúng (khớp với MaTour)
        [Display(Name = "Mã tour")]
        public string? TourId { get; set; }

        [ForeignKey("TourId")]
        public virtual Tour? Tour { get; set; }

        [Required]
        [Display(Name = "Người dùng")]
        public string UserId { get; set; } = string.Empty;

        [ForeignKey("UserId")]
        public virtual ApplicationUser? User { get; set; }

        [Range(1, 5, ErrorMessage = "Vui lòng đánh giá từ 1 đến 5 sao")]
        [Display(Name = "Số sao")]
        public int SoSao { get; set; }

        [StringLength(2000)]
        [Display(Name = "Bình luận")]
        public string? BinhLuan { get; set; }

        [StringLength(500)]
        [Display(Name = "Ảnh minh họa")]
        public string? HinhAnhUrl { get; set; }

        [Display(Name = "Ngày đánh giá")]
        public DateTime NgayDanhGia { get; set; }

        [Display(Name = "Ngày cập nhật")]
        public DateTime? NgayCapNhat { get; set; }

        [Display(Name = "Ngày tạo hệ thống")]
        public DateTime NgayTao { get; set; }
    }
}
﻿// Folder: Models/ViewModels
// File path: Models/ViewModels/DanhGiaTourViewModels.cs

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Tour_2040.Models
{
    // ITEM LIST - Hiển thị danh sách đánh giá
    public class DanhGiaTourItemViewModel
    {
        // Khớp với DanhGiaTour.MaDanhGia (string)
        public string Id { get; set; } = string.Empty;

        // Khớp với LichTrinh.MaLichTrinh (string)
        public string LichTrinhId { get; set; } = string.Empty;

        // Khớp với Tour.MaTour (string)
        public string? TourId { get; set; }

        public string? UserId { get; set; }

        public string TenNguoiDung { get; set; } = "Khách";

        public int SoSao { get; set; }

        public string? BinhLuan { get; set; }

        public string? HinhAnhUrl { get; set; }

        public DateTime NgayTao { get; set; }
    }

    // TẠO ĐÁNH GIÁ
    public class DanhGiaTourCreateViewModel
    {
        [Required]
        // Khớp với LichTrinh.MaLichTrinh (string)
        public string LichTrinhId { get; set; } = string.Empty;

        [Display(Name = "Tên tour / lịch trình")]
        public string TenTourHoacLichTrinh { get; set; } = string.Empty;

        [Required]
        [Range(1, 5, ErrorMessage = "Số sao phải từ 1 đến 5.")]
        [Display(Name = "Số sao")]
        public int SoSao { get; set; } = 5;

        [Display(Name = "Bình luận")]
        [StringLength(2000)]
        public string? BinhLuan { get; set; }

        [Display(Name = "Ảnh minh hoạ (tuỳ chọn)")]
        public IFormFile? HinhAnhFile { get; set; }

        // Danh sách đánh giá hiện có để hiển thị bên dưới
        public IEnumerable<DanhGiaTourItemViewModel>? DanhGias { get; set; }
    }

    // SỬA ĐÁNH GIÁ
    public class DanhGiaTourEditViewModel
    {
        [Required]
        // Khớp với DanhGiaTour.MaDanhGia (string)
        public string Id { get; set; } = string.Empty;

        [Required]
        // Khớp với LichTrinh.MaLichTrinh (string)
        public string LichTrinhId { get; set; } = string.Empty;

        [Display(Name = "Tên tour / lịch trình")]
        public string TenTourHoacLichTrinh { get; set; } = string.Empty;

        [Required]
        [Range(1, 5, ErrorMessage = "Số sao phải từ 1 đến 5.")]
        [Display(Name = "Số sao")]
        public int SoSao { get; set; }

        [Display(Name = "Bình luận")]
        [StringLength(2000)]
        public string? BinhLuan { get; set; }

        [Display(Name = "Ảnh hiện tại")]
        public string? HinhAnhUrl { get; set; }

        [Display(Name = "Ảnh mới (nếu muốn thay)")]
        public IFormFile? HinhAnhFile { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using Tour_2040.Models; // Đảm bảo namespace này để nhận diện class DichVu

namespace Tour_2040.Models.ViewModels
{
    public class TourCreateViewModel
    {
        // --- THÔNG TIN ĐỊNH DANH ---
        [Display(Name = "Mã Tour")]
        [StringLength(50)]
        public string? MaTour { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập tên tour du lịch")]
        [StringLength(250, ErrorMessage = "Tên tour tối đa 250 ký tự")]
        [Display(Name = "Tên hành trình")]
        public string TenTour { get; set; } = string.Empty;

        // --- PHÂN LOẠI VÀ ĐỊA ĐIỂM ---
        [Required(ErrorMessage = "Vui lòng chọn loại hình tour")]
        [Display(Name = "Phân loại Tour")]
        public string? LoaiTour { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập điểm xuất phát")]
        [StringLength(200)]
        [Display(Name = "Điểm khởi hành")]
        public string? NoiKhoiHanh { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập địa điểm đến")]
        [StringLength(200)]
        [Display(Name = "Điểm đến chính")]
        public string? DiaDiem { get; set; }

        // --- THỜI GIAN ---
        [Required(ErrorMessage = "Vui lòng chọn ngày đi")]
        [Display(Name = "Ngày khởi hành")]
        [DataType(DataType.Date)]
        public DateTime? NgayDi { get; set; } = DateTime.Today.AddDays(7);

        [Required(ErrorMessage = "Vui lòng chọn ngày về")]
        [Display(Name = "Ngày kết thúc")]
        [DataType(DataType.Date)]
        public DateTime? NgayVe { get; set; } = DateTime.Today.AddDays(10);

        // --- SỐ LƯỢNG VÀ TÀI CHÍNH ---
        [Required(ErrorMessage = "Vui lòng nhập số khách tối đa")]
        [Range(1, 500, ErrorMessage = "Số lượng khách phải từ 1 đến 500")]
        [Display(Name = "Số chỗ tối đa")]
        public int SoNguoiToiDa { get; set; } = 20;

        // [FIX LỖI TẠI ĐÂY] - Bổ sung thuộc tính thiếu
        [Display(Name = "Số khách hiện tại")]
        public int SoNguoiHienTai { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập giá bán")]
        [Range(0, 1000000000, ErrorMessage = "Giá tour không hợp lệ")]
        [Display(Name = "Giá trọn gói (VNĐ)")]
        [DataType(DataType.Currency)]
        public decimal GiaTour { get; set; }

        [Display(Name = "Mô tả lịch trình chi tiết")]
        public string? MoTa { get; set; }

        // --- FILE ẢNH ---
        [Display(Name = "Ảnh đại diện Tour")]
        public IFormFile? AnhTourFile { get; set; }

        [Display(Name = "Đường dẫn ảnh hiện tại")]
        public string? HinhAnhTourUrl { get; set; }

        // --- DỊCH VỤ ĐI KÈM ---
        [Display(Name = "Dịch vụ đính kèm")]
        public List<string> SelectedDichVuIds { get; set; } = new List<string>();

        // Danh sách dịch vụ để load ra Checkbox
        public List<DichVu> AvailableDichVus { get; set; } = new List<DichVu>();

        // Giữ lại theo yêu cầu (không xóa)
        public List<string> SelectedServiceIds { get; set; } = new List<string>();
    }
}

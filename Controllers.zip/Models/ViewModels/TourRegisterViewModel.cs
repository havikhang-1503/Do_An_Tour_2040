﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http; // Cần thiết để dùng IFormFile

namespace Tour_2040.Models
{
    public class TourRegisterViewModel
    {
        // --- 1. THÔNG TIN TOUR (Dùng để hiển thị lại) ---
        [Required]
        public string TourId { get; set; } = string.Empty;

        [Display(Name = "Mã hành trình")]
        public string? MaTour { get; set; }

        [Display(Name = "Tên tour")]
        public string TenTour { get; set; } = string.Empty;

        public string? HinhAnhTourUrl { get; set; }

        [Display(Name = "Điểm đến")]
        public string? DiaDiem { get; set; }

        [Display(Name = "Nơi khởi hành")]
        public string? NoiKhoiHanh { get; set; }

        [Display(Name = "Ngày khởi hành")]
        [DataType(DataType.Date)]
        public DateTime? NgayDi { get; set; }

        [Display(Name = "Ngày về")]
        [DataType(DataType.Date)]
        public DateTime? NgayVe { get; set; }

        [Display(Name = "Mô tả")]
        public string? MoTa { get; set; }

        [Display(Name = "Giá tour")]
        public decimal GiaTour { get; set; }


        // --- 2. THÔNG TIN NGƯỜI ĐĂNG KÝ (VALIDATION CHẶT CHẼ) ---

        [Display(Name = "Họ tên người đại diện")]
        [Required(ErrorMessage = "Vui lòng nhập họ tên.")]
        // Regex: Chấp nhận mọi ký tự TRỪ số (0-9)
        [RegularExpression(@"^[^0-9]*$", ErrorMessage = "Họ tên không được chứa số.")]
        public string HoTenDaiDien { get; set; } = string.Empty;

        // --- BỔ SUNG: NGÀY SINH ĐỂ CHECK TUỔI ---
        [Display(Name = "Ngày sinh")]
        [Required(ErrorMessage = "Vui lòng nhập ngày sinh.")]
        [DataType(DataType.Date)]
        // Validation: Phải đủ 16 tuổi
        [MinAge(16, ErrorMessage = "Người đại diện phải đủ 16 tuổi để đăng ký.")]
        public DateTime? NgaySinh { get; set; }

        [Display(Name = "Số điện thoại")]
        [Required(ErrorMessage = "Vui lòng nhập số điện thoại.")]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Số điện thoại phải đúng 10 chữ số.")]
        // Regex: Bắt đầu bằng 0, theo sau là 9 chữ số
        [RegularExpression(@"^0\d{9}$", ErrorMessage = "SĐT không hợp lệ (Phải bắt đầu bằng số 0).")]
        public string SoDienThoai { get; set; } = string.Empty;

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Vui lòng nhập Email.")]
        [EmailAddress(ErrorMessage = "Địa chỉ Email không hợp lệ.")]
        public string Email { get; set; } = string.Empty;

        [Display(Name = "Số CCCD/CMND")]
        [Required(ErrorMessage = "Vui lòng nhập số CCCD.")]
        [StringLength(12, MinimumLength = 12, ErrorMessage = "CCCD phải đúng 12 chữ số.")]
        // Regex: Chỉ chấp nhận ký tự số
        [RegularExpression(@"^\d{12}$", ErrorMessage = "CCCD chỉ được chứa số.")]
        public string CCCD { get; set; } = string.Empty;

        [Display(Name = "Địa chỉ liên hệ")]
        [Required(ErrorMessage = "Vui lòng nhập địa chỉ liên hệ.")]
        public string DiaChiLienHe { get; set; } = string.Empty;

        // ...
        [Display(Name = "Ảnh CCCD mặt trước")]
        [Required(ErrorMessage = "Vui lòng tải lên ảnh mặt trước CCCD.")]
        [DataType(DataType.Upload)]
        public IFormFile? AnhCCCDFile { get; set; }
        // ...


        // --- 3. SỐ LƯỢNG KHÁCH & TÍNH TOÁN ---

        [Display(Name = "Số người lớn")]
        [Range(1, 100, ErrorMessage = "Ít nhất phải có 1 người lớn tham gia.")]
        public int SoNguoiLon { get; set; } = 1;

        [Display(Name = "Số trẻ em")]
        [Range(0, 100, ErrorMessage = "Số lượng không hợp lệ.")]
        public int SoTreEm { get; set; } = 0;

        [Display(Name = "Ghi chú thêm")]
        public string? GhiChu { get; set; }

        [Display(Name = "Tổng tiền dự kiến")]
        public decimal TongTienDuKien { get; set; }
        
    }

    // --- CLASS CUSTOM VALIDATION: CHECK TUỔI ---
    public class MinAgeAttribute : ValidationAttribute
    {
        private int _limit;
        public MinAgeAttribute(int limit) { _limit = limit; }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null) return ValidationResult.Success; // Để Required lo check null
            DateTime dt = (DateTime)value;
            // Logic: Nếu ngày sinh + 16 năm mà vẫn lớn hơn ngày hiện tại => Chưa đủ 16 tuổi
            if (dt.AddYears(_limit) > DateTime.Now)
            {
                return new ValidationResult(ErrorMessage);
            }
            return ValidationResult.Success;
        }
    }
}
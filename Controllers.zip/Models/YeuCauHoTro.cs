﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tour_2040.Utils;

namespace Tour_2040.Models
{
    [Table("YeuCauHoTros")]
    public class YeuCauHoTro
    {
        public YeuCauHoTro()
        {
            this.MaYeuCauHoTro = MaSoHelper.TaoMa("MYC");
            this.NgayGui = DateTime.Now;
            this.TrangThai = "Chờ xử lý";
            this.LoaiHoTro = string.Empty;
            this.ChuDe = string.Empty;
            this.NoiDung = string.Empty;
            this.TinNhanHoTros = new List<TinNhanHoTro>();
        }

        [Key]
        [Required]
        [StringLength(50)]
        [Display(Name = "Mã yêu cầu")]
        public string MaYeuCauHoTro { get; set; }

        [StringLength(450)] public string? UserId { get; set; }
        [ForeignKey("UserId")] public virtual ApplicationUser? User { get; set; }

        [StringLength(150)] public string? KhachHangId { get; set; }
        [ForeignKey("KhachHangId")] public virtual KhachHang? KhachHang { get; set; }

        [StringLength(50)][Display(Name = "Mã giao dịch")] public string? MaGiaoDich { get; set; }
        [ForeignKey("MaGiaoDich")] public virtual GiaoDich? GiaoDich { get; set; }

        [Required(ErrorMessage = "Vui lòng chọn loại hỗ trợ")]
        [StringLength(100)][Display(Name = "Phân loại")] public string LoaiHoTro { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập chủ đề")]
        [StringLength(200)][Display(Name = "Chủ đề")] public string ChuDe { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập nội dung chi tiết")]
        [Display(Name = "Nội dung")] public string NoiDung { get; set; }

        [Display(Name = "Ngày gửi")] public DateTime NgayGui { get; set; }

        [StringLength(50)][Display(Name = "Trạng thái")] public string TrangThai { get; set; }

        [Display(Name = "Nội dung phản hồi")] public string? TraLoi { get; set; }
        [Display(Name = "Ngày phản hồi")] public DateTime? NgayTraLoi { get; set; }

        [NotMapped]
        public string Id { get { return MaYeuCauHoTro; } set { MaYeuCauHoTro = value; } }

        public virtual ICollection<TinNhanHoTro> TinNhanHoTros { get; set; }
    }
}
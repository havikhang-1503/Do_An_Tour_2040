﻿// Folder: Models
// File path: Models/LichTrinhChiTiet.cs

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tour_2040.Utils;

namespace Tour_2040.Models
{
    public class LichTrinhChiTiet
    {
        public LichTrinhChiTiet()
        {
            // Tự động sinh mã chi tiết: MCTLT + 6 số
            this.MaLichTrinhChiTiet = MaSoHelper.TaoMa("MCTLT");
            this.DichVuKemTheo = new List<LichTrinhChiTietDichVu>();

            // Default: Ngày 1
            this.NgayThu = 1;
        }

        [Key]
        [Required, StringLength(50)]
        [Display(Name = "Mã chi tiết lịch trình")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string MaLichTrinhChiTiet { get; set; }

        [Required]
        [StringLength(20)]
        [Display(Name = "Mã lịch trình")]
        public string LichTrinhId { get; set; } = string.Empty;

        [ForeignKey("LichTrinhId")]
        public virtual LichTrinh? LichTrinh { get; set; }

        // ✅ NEW: ngày thứ mấy trong tour (1..n)
        [Range(1, 365)]
        [Display(Name = "Ngày thứ")]
        public int NgayThu { get; set; }

        [StringLength(20)]
        [Display(Name = "Địa điểm")]
        public string? DiaDiemId { get; set; }

        [ForeignKey("DiaDiemId")]
        public virtual DiaDiem? DiaDiem { get; set; }

        [Required(ErrorMessage = "Vui lòng chọn giờ")]
        [Column(TypeName = "time")]
        [Display(Name = "Giờ")]
        public TimeSpan Gio { get; set; }

        [Display(Name = "Thứ tự")]
        public int ThuTu { get; set; }

        // ✅ Dùng NoiDung làm mô tả hành động chính
        [StringLength(200)]
        [Display(Name = "Nội dung")]
        public string? NoiDung { get; set; }

        [StringLength(500)]
        [Display(Name = "Ghi chú")]
        public string? GhiChu { get; set; }

        [StringLength(50)]
        [Display(Name = "Loại hoạt động")]
        public string? LoaiHoatDong { get; set; }

        public virtual ICollection<LichTrinhChiTietDichVu> DichVuKemTheo { get; set; }
    }
}

﻿// Folder: Models
// File path: Models/DiaDiem.cs

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tour_2040.Utils;

namespace Tour_2040.Models
{
    [Table("DiaDiem")]
    public class DiaDiem
    {
        public DiaDiem()
        {
            // Auto-generate Location Code: MDD + 6 digits
            this.MaDiaDiem = MaSoHelper.TaoMa("MDD");
            this.DichVus = new List<DichVu>();
            this.ConSuDung = true;
        }

        [Key]
        [Required]
        [StringLength(20)]
        [Display(Name = "Mã địa điểm")]
        [Column("MaDiaDiem")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string MaDiaDiem { get; set; }

        [Required(ErrorMessage = "Tên địa điểm không được để trống")]
        [StringLength(200)]
        [Display(Name = "Tên địa điểm")]
        [Column("TenDiaDiem")]
        public string TenDiaDiem { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Xã / Phường")]
        [Column("XaPhuongId")]
        public int XaPhuongId { get; set; }

        [ForeignKey("XaPhuongId")]
        public virtual XaPhuong? XaPhuong { get; set; }

        [StringLength(500)]
        [Display(Name = "Địa chỉ chi tiết")]
        [Column("DiaChiChiTiet")]
        public string? DiaChiChiTiet { get; set; }

        [Display(Name = "Mô tả")]
        [Column("MoTa")]
        public string? MoTa { get; set; }

        [Display(Name = "Còn sử dụng")]
        [Column("ConSuDung")]
        public bool ConSuDung { get; set; }

        // Mối quan hệ 1-N với DichVu
        public virtual ICollection<DichVu> DichVus { get; set; }
    }
}
﻿// Folder: Models
// File path: Models/LichTrinh.cs

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tour_2040.Utils;

namespace Tour_2040.Models
{
    public class LichTrinh
    {
        public LichTrinh()
        {
            // Tự động sinh mã: MLT + 6 số
            this.MaLichTrinh = MaSoHelper.TaoMa("MLT");
            this.NgayDat = DateTime.Now;
            this.TrangThai = "Chờ xác nhận";

            this.LichTrinhChiTiets = new List<LichTrinhChiTiet>();
            this.DanhGiaTours = new List<DanhGiaTour>();
        }

        [Key]
        [Required, StringLength(20)]
        [Display(Name = "Mã lịch trình")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string MaLichTrinh { get; set; }

        [Required]
        [StringLength(20)]
        [Display(Name = "Mã Tour")]
        public string TourId { get; set; } = string.Empty;

        [ForeignKey("TourId")]
        public virtual Tour? Tour { get; set; }

        [StringLength(450)]
        [Display(Name = "Người đặt")]
        public string? UserId { get; set; }

        [ForeignKey(nameof(UserId))]
        public virtual ApplicationUser? User { get; set; }

        [Display(Name = "Tên lịch trình")]
        [StringLength(200)]
        public string? TenLichTrinh { get; set; }

        [Display(Name = "Ngày đặt")]
        public DateTime NgayDat { get; set; }

        [Display(Name = "Số người lớn")]
        public int SoNguoiLon { get; set; }

        [Display(Name = "Số trẻ em")]
        public int SoTreEm { get; set; }

        // --- Cột bị thiếu gây lỗi ---
        [Display(Name = "Tổng tiền")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal TongTien { get; set; }

        [StringLength(50)]
        [Display(Name = "Trạng thái")]
        public string? TrangThai { get; set; }
        public string? GiaoDichId { get; set; }

        [ForeignKey("GiaoDichId")]
        public virtual GiaoDich? GiaoDich { get; set; }

        public virtual ICollection<LichTrinhChiTiet> LichTrinhChiTiets { get; set; }
        public virtual ICollection<DanhGiaTour> DanhGiaTours { get; set; }

    }
}
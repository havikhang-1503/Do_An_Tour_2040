﻿// Folder: Models
// File path: Models/ApplicationUser.cs

using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tour_2040.Models
{
    public class ApplicationUser : IdentityUser
    {
        public ApplicationUser()
        {
            // Khởi tạo danh sách để tránh lỗi NullReferenceException
            this.GiaoDiches = new List<GiaoDich>();
            this.HopDongs = new List<HopDong>();
            this.YeuCauHoTros = new List<YeuCauHoTro>();
        }

        [StringLength(100)]
        [Display(Name = "Họ tên")]
        public string? HoTen { get; set; }

        [StringLength(50)]
        [Display(Name = "Mã người dùng")]
        public string? MaNguoiDung { get; set; }

        [StringLength(12)]
        [Display(Name = "CCCD/CMND")]
        public string? CCCD { get; set; }

        [StringLength(200)]
        [Display(Name = "Địa chỉ")]
        public string? DiaChi { get; set; }

        public string? AnhCCCDUrl { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Ngày sinh")]
        public DateTime? NgaySinh { get; set; }

        // --- QUAN TRỌNG: Ảnh đại diện ---

        // 1. Đường dẫn ảnh (Lưu vào Database)
        public string? ProfilePictureUrl { get; set; }

        // 2. File ảnh vật lý (Chỉ dùng để Upload, KHÔNG tạo cột trong DB)
        [Display(Name = "Ảnh đại diện")]
        [NotMapped]
        public IFormFile? AvatarFile { get; set; }

        // Navigation Properties (Các bảng liên kết)
        public virtual ICollection<GiaoDich> GiaoDiches { get; set; }
        public virtual ICollection<HopDong> HopDongs { get; set; }
        public virtual ICollection<YeuCauHoTro> YeuCauHoTros { get; set; }
    }
}
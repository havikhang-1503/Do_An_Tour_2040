﻿// Folder: Models
// File path: Models/GiaoDich.cs

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tour_2040.Utils;

namespace Tour_2040.Models
{
    public class GiaoDich
    {
        public GiaoDich()
        {
            // Tự động sinh mã giao dịch: MGD + 6 số
            this.MaGiaoDich = MaSoHelper.TaoMa("MGD");
            this.NgayTao = DateTime.Now;
            this.TrangThai = "Pending";
            this.SoNguoiLon = 1;
            this.SoTreEm = 0;

            // Khởi tạo danh sách liên kết để tránh lỗi NullReference
            this.ChiTietDichVus = new List<GiaoDichChiTiet>();
            this.ThanhToans = new List<ThanhToan>();
            this.HopDongs = new List<HopDong>();
            this.YeuCauHoTros = new List<YeuCauHoTro>();

            // ✅ FIX: init luôn LichTrinhs để tránh null
            this.LichTrinhs = new List<LichTrinh>();
        }

        // --- KHÓA CHÍNH ---
        [Key]
        [Required, StringLength(50)]
        [Display(Name = "Mã giao dịch")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)] // Không tự tăng, dùng mã chuỗi
        public string MaGiaoDich { get; set; }

        // --- LIÊN KẾT USER (Identity) ---
        [Required]
        [Display(Name = "User ID")]
        public string UserId { get; set; } = string.Empty;

        [ForeignKey(nameof(UserId))]
        public virtual ApplicationUser? User { get; set; }

        // --- LIÊN KẾT KHÁCH HÀNG (CRM) ---
        // Lưu ý: Khớp độ dài 150 với KhachHang.MaTenKhachHang
        [Display(Name = "Khách hàng")]
        [StringLength(150)]
        public string? KhachHangId { get; set; }

        [ForeignKey(nameof(KhachHangId))]
        public virtual KhachHang? KhachHang { get; set; }

        // --- LIÊN KẾT TOUR ---
        // Lưu ý: Khớp độ dài 20 với Tour.MaTour
        [Display(Name = "Tour")]
        [StringLength(20)]
        public string? TourId { get; set; }

        [ForeignKey(nameof(TourId))]
        public virtual Tour? Tour { get; set; }

        // --- THÔNG TIN CHI TIẾT ---
        [Display(Name = "Số người lớn")]
        [Range(1, int.MaxValue, ErrorMessage = "Số người lớn tối thiểu là 1")]
        public int SoNguoiLon { get; set; }

        [Display(Name = "Số trẻ em")]
        [Range(0, int.MaxValue)]
        public int SoTreEm { get; set; }

        [Display(Name = "Ngày tạo")]
        public DateTime NgayTao { get; set; }

        [Display(Name = "Tổng tiền")]
        [Column(TypeName = "decimal(18,2)")]
        [Range(0, double.MaxValue)]
        public decimal TongTien { get; set; }

        [StringLength(50)]
        [Display(Name = "Trạng thái")]
        public string? TrangThai { get; set; }

        [StringLength(500)]
        [Display(Name = "Ghi chú")]
        public string? GhiChu { get; set; }

        // ==========================================================
        // ✅ SNAPSHOT THÔNG TIN KHÁCH HÀNG (lấy từ BatDauThanhToan)
        // Mục tiêu: Details giao dịch hiển thị đúng "người đại diện"
        // ==========================================================

        [StringLength(150)]
        [Display(Name = "Họ tên người đại diện")]
        public string? HoTenNguoiDaiDien { get; set; }

        [StringLength(20)]
        [Display(Name = "Số điện thoại")]
        public string? SoDienThoai { get; set; }

        [StringLength(150)]
        [Display(Name = "Email liên hệ")]
        public string? Email { get; set; }

        [StringLength(50)]
        [Display(Name = "CCCD / CMND")]
        public string? CCCD { get; set; }

        [StringLength(300)]
        [Display(Name = "Địa chỉ liên hệ")]
        public string? DiaChiLienHe { get; set; }

        [Display(Name = "Ngày sinh")]
        public DateTime? NgaySinh { get; set; }

        [StringLength(500)]
        [Display(Name = "Ảnh CCCD")]
        public string? AnhCCCDUrl { get; set; }

        // --- DANH SÁCH LIÊN KẾT (1-N) ---
        public virtual ICollection<GiaoDichChiTiet> ChiTietDichVus { get; set; }

        public virtual ICollection<ThanhToan> ThanhToans { get; set; }
        public virtual ICollection<HopDong> HopDongs { get; set; }
        public virtual ICollection<YeuCauHoTro> YeuCauHoTros { get; set; }
        public virtual ICollection<LichTrinh> LichTrinhs { get; set; }
    }
}

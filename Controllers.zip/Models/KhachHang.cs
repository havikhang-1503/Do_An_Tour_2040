﻿// Folder: Models
// File path: Models/KhachHang.cs

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tour_2040.Utils;

namespace Tour_2040.Models
{
    public class KhachHang
    {
        public KhachHang()
        {
            // Auto-generate Customer Code: MKH + 6 digits
            this.MaKhachHang = MaSoHelper.TaoMa("MKH");
            // Set Primary Key to generated code
            this.MaTenKhachHang = this.MaKhachHang;

            this.NgayTao = DateTime.Now;
            this.NhomKhach = "Thường";
            this.TrangThaiTour = "Chưa đặt tour";
            this.IsVip = false;

            // Initialize collections
            this.GiaoDiches = new List<GiaoDich>();
            this.ThanhToans = new List<ThanhToan>();
            this.YeuCauHoTros = new List<YeuCauHoTro>();
            this.HopDongs = new List<HopDong>();
        }

        // Gộp chung: Sử dụng chuỗi MaTenKhachHang làm Khóa chính (Primary Key)
        [Key]
        [Required, StringLength(150)]
        [Display(Name = "Mã và Tên khách hàng")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)] // Không tự sinh số, hệ thống sẽ nhập chuỗi định danh
        public string MaTenKhachHang { get; set; }

        [Required, StringLength(20)]
        [Display(Name = "Mã khách hàng")]
        public string MaKhachHang { get; set; }

        [Required(ErrorMessage = "Họ tên khách hàng không được để trống")]
        [StringLength(100)]
        [Display(Name = "Họ tên")]
        public string HoTen { get; set; } = string.Empty;

        [StringLength(12)]
        [Display(Name = "CCCD/CMND")]
        public string? CCCD { get; set; }

        [StringLength(100)]
        [EmailAddress(ErrorMessage = "Email không hợp lệ")]
        [Display(Name = "Email")]
        public string? Email { get; set; }

        [StringLength(20)]
        [Phone(ErrorMessage = "Số điện thoại không hợp lệ")]
        [Display(Name = "Số điện thoại")]
        public string? SoDienThoai { get; set; }

        [StringLength(200)]
        [Display(Name = "Địa chỉ")]
        public string? DiaChi { get; set; }

        [DataType(DataType.Date)]
        [Display(Name = "Ngày sinh")]
        public DateTime? NgaySinh { get; set; }

        [Required, StringLength(20)]
        [Display(Name = "Nhóm khách")]
        public string NhomKhach { get; set; }

        [Required, StringLength(50)]
        [Display(Name = "Trạng thái tour")]
        public string TrangThaiTour { get; set; }

        [Display(Name = "Ngày tạo")]
        public DateTime NgayTao { get; set; }

        [Display(Name = "Khách VIP")]
        public bool IsVip { get; set; }

        [StringLength(300)]
        [Display(Name = "Ghi chú")]
        public string? GhiChu { get; set; }

        // ===== QUAN HỆ (CHÚ Ý: Khóa ngoại ở các bảng này phải đổi sang kiểu String) =====

        public virtual ICollection<GiaoDich> GiaoDiches { get; set; }
        public virtual ICollection<ThanhToan> ThanhToans { get; set; }
        public virtual ICollection<YeuCauHoTro> YeuCauHoTros { get; set; }
        public virtual ICollection<HopDong> HopDongs { get; set; }
    }
}
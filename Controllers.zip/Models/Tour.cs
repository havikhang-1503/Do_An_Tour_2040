﻿// Folder: Models
// File path: Models/Tour.cs

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tour_2040.Utils;

namespace Tour_2040.Models
{
    public class Tour
    {
        public Tour()
        {
            this.MaTour = MaSoHelper.TaoMa("MT");
            this.NgayTao = DateTime.Now;
            this.SoNguoiHienTai = 0;
            this.IsDefault = true;
            this.IsPersonal = false;
            this.IsHidden = false;
            this.TrangThai = "ChoDuyet";

            this.GiaoDiches = new List<GiaoDich>();
            this.HopDongs = new List<HopDong>();
            this.TourDichVus = new List<TourDichVu>();
        }

        [Key]
        [Required, StringLength(20)]
        [Display(Name = "Mã Tour")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string MaTour { get; set; }

        [Required(ErrorMessage = "Tên tour là bắt buộc")]
        [StringLength(250)]
        [Display(Name = "Tên tour")]
        public string TenTour { get; set; } = string.Empty;

        [StringLength(100)]
        [Display(Name = "Loại tour")]
        public string? LoaiTour { get; set; }

        [StringLength(200)]
        [Display(Name = "Điểm xuất phát")]
        public string? NoiKhoiHanh { get; set; }

        [StringLength(200)]
        [Display(Name = "Địa điểm chính")]
        public string? DiaDiem { get; set; }

        [StringLength(2000)]
        [Display(Name = "Mô tả")]
        public string? MoTa { get; set; }

        [Required(ErrorMessage = "Giá tour không được để trống")]
        [Display(Name = "Giá tour")]
        [Column(TypeName = "decimal(18,2)")]
        [Range(0, double.MaxValue)]
        public decimal GiaTour { get; set; }

        [StringLength(450)]
        public string? UserId { get; set; }

        [ForeignKey(nameof(UserId))]
        public virtual ApplicationUser? User { get; set; }

        [StringLength(50)]
        [Display(Name = "Trạng thái duyệt")]
        public string? TrangThai { get; set; }

        [Display(Name = "Ngày tạo")]
        public DateTime NgayTao { get; set; }

        [Display(Name = "Số người tối đa")]
        public int? SoNguoiToiDa { get; set; }

        [Display(Name = "Số người hiện tại")]
        public int? SoNguoiHienTai { get; set; }

        [Display(Name = "Ngày đi")]
        [DataType(DataType.Date)]
        public DateTime? NgayDi { get; set; }

        [Display(Name = "Ngày về")]
        [DataType(DataType.Date)]
        public DateTime? NgayVe { get; set; }

        [Display(Name = "Tour mặc định")]
        public bool IsDefault { get; set; }

        [Display(Name = "Tour cá nhân")]
        public bool IsPersonal { get; set; }

        [StringLength(300)]
        [Display(Name = "Ảnh đại diện")]
        public string? HinhAnhTourUrl { get; set; }

        [Display(Name = "Ẩn tour")]
        public bool IsHidden { get; set; }

        [StringLength(1000)]
        [Display(Name = "Yêu cầu lưu trú")]
        public string? YeuCauKhachSan { get; set; }

        [StringLength(1000)]
        [Display(Name = "Yêu cầu ẩm thực")]
        public string? YeuCauNhaHang { get; set; }

        [StringLength(1000)]
        [Display(Name = "Yêu cầu di chuyển")]
        public string? YeuCauPhuongTien { get; set; }

        [StringLength(1000)]
        [Display(Name = "Yêu cầu trải nghiệm")]
        public string? YeuCauVuiChoi { get; set; }

        [StringLength(1000)]
        [Display(Name = "Ghi chú khác")]
        public string? YeuCauKhac { get; set; }

        public virtual ICollection<GiaoDich> GiaoDiches { get; set; }
        public virtual ICollection<HopDong> HopDongs { get; set; }
        public virtual ICollection<TourDichVu> TourDichVus { get; set; }
    }
}
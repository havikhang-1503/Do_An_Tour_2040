﻿// Folder: Models
// File path: Models/ThanhToan.cs

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tour_2040.Utils;

namespace Tour_2040.Models
{
    public class ThanhToan
    {
        public ThanhToan()
        {
            // Tự động sinh mã thanh toán: MTT + 6 số
            this.MaThanhToan = MaSoHelper.TaoMa("MTT");
            this.NgayThanhToan = DateTime.Now;
            this.TrangThai = "Thành công";
        }

        // --- KHÓA CHÍNH ---
        [Key]
        [Required, StringLength(50)]
        [Display(Name = "Mã thanh toán")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string MaThanhToan { get; set; }

        // --- KHÓA NGOẠI (Sửa thành GiaoDichId để khớp code Controller) ---
        [Required, StringLength(50)]
        [Display(Name = "Mã giao dịch")]
        public string GiaoDichId { get; set; } = string.Empty;

        [ForeignKey("GiaoDichId")]
        public virtual GiaoDich? GiaoDich { get; set; }

        // --- THÔNG TIN TÀI CHÍNH ---
        [Required]
        [Column(TypeName = "decimal(18,2)")]
        [Display(Name = "Số tiền thanh toán")]
        [Range(0, double.MaxValue)]
        public decimal SoTien { get; set; }

        [Required, StringLength(100)]
        [Display(Name = "Phương thức")]
        public string PhuongThuc { get; set; } = string.Empty; // Chuyển khoản, MoMo...

        // --- THÔNG TIN BỔ SUNG ---
        [StringLength(200)]
        [Display(Name = "Tên tài khoản thanh toán")]
        public string? TenTaiKhoan { get; set; }

        [StringLength(100)]
        [Display(Name = "Số tài khoản / Ví")]
        public string? SoTaiKhoan { get; set; }

        [StringLength(500)]
        [Display(Name = "Nội dung / Ghi chú")]
        public string? GhiChu { get; set; }

        [Display(Name = "Ngày thanh toán")]
        public DateTime NgayThanhToan { get; set; }

        [StringLength(50)]
        [Display(Name = "Trạng thái")]
        public string? TrangThai { get; set; }

        // --- LIÊN KẾT KHÁCH HÀNG ---
        [Display(Name = "Khách hàng")]
        [StringLength(150)] // Khớp với KhachHang.MaTenKhachHang
        public string? KhachHangId { get; set; }

        [ForeignKey("KhachHangId")]
        public virtual KhachHang? KhachHang { get; set; }
    }
}
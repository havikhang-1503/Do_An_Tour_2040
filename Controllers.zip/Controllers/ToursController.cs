﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Tour_2040.Data;
using Tour_2040.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Tour_2040.Models.ViewModels; // Đảm bảo namespace này tồn tại
using Tour_2040.Utils;             // Đảm bảo namespace này tồn tại

namespace Tour_2040.Controllers
{
    [Authorize]
    public class ToursController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IWebHostEnvironment _env;
        private readonly ILogger<ToursController> _logger;

        public ToursController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            IWebHostEnvironment env,
            ILogger<ToursController> logger)
        {
            _context = context;
            _userManager = userManager;
            _env = env;
            _logger = logger;
        }

        #region ================== 1. HELPER METHODS (XỬ LÝ FILE & LOGIC PHỤ) ==================
        private bool IsAdminOrStaff =>
            User.Identity != null && User.Identity.IsAuthenticated &&
            (User.IsInRole("Admin") || User.IsInRole("Staff"));

        private string GenerateMaTour(string prefix)
        {
            return MaSoHelper.TaoMa(prefix);
        }

        // Hàm Upload file đa năng (Dùng cho cả CCCD và Ảnh Tour)
        private async Task<string?> UploadFile(IFormFile? file, string folderName)
        {
            if (file == null || file.Length == 0) return null;
            try
            {
                // Tạo đường dẫn: wwwroot/uploads/{folderName}
                var uploadPath = Path.Combine(_env.WebRootPath, "uploads", folderName);

                // Tự động tạo thư mục nếu chưa có
                if (!Directory.Exists(uploadPath)) Directory.CreateDirectory(uploadPath);

                var fileExtension = Path.GetExtension(file.FileName);
                // Đặt tên file ngẫu nhiên để tránh trùng lặp
                var fileName = $"{folderName}-{Guid.NewGuid()}{fileExtension}";
                var filePath = Path.Combine(uploadPath, fileName);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                // Trả về đường dẫn tương đối để lưu vào DB
                return $"/uploads/{folderName}/{fileName}";
            }
            catch (Exception ex)
            {
                _logger.LogError($"Lỗi upload file: {ex.Message}");
                return null;
            }
        }

        private void DeleteOldImage(string? imageUrl)
        {
            if (string.IsNullOrEmpty(imageUrl)) return;
            try
            {
                var localPath = Path.Combine(_env.WebRootPath, imageUrl.TrimStart('/'));
                if (System.IO.File.Exists(localPath)) System.IO.File.Delete(localPath);
            }
            catch (Exception ex)
            {
                _logger.LogWarning($"Không thể xóa ảnh cũ: {ex.Message}");
            }
        }

        // ================== [NEW] LOAD DATA CHO CREATE/EDIT ADMIN ==================
        private async Task LoadTourCreateDataAsync(TourCreateViewModel vm)
        {
            var diaDiems = await _context.DiaDiems
                .OrderBy(d => d.TenDiaDiem)
                .ToListAsync();

            // View đang dùng ViewBag.DiaDiemList, set ViewData vẫn ok vì ViewBag wrap ViewData
            ViewData["DiaDiemList"] = new SelectList(diaDiems, "TenDiaDiem", "TenDiaDiem");

            // Load dịch vụ để view dùng Model.AvailableDichVus
            vm.AvailableDichVus = await _context.DichVus
                .Where(d => d.TrangThai == "Active")
                .OrderBy(d => d.LoaiDichVu)
                .ThenBy(d => d.TenDichVu)
                .ToListAsync();

            // Giữ lại ViewBag.DichVuList nếu chỗ khác còn xài (không xóa)
            ViewBag.DichVuList = vm.AvailableDichVus;
        }

        private List<string> GetSelectedDichVuIdsUnified(TourCreateViewModel model)
        {
            // Giữ lại SelectedServiceIds theo yêu cầu (không xóa), nên unify cho khỏi lệch
            var a = model.SelectedDichVuIds ?? new List<string>();
            var b = model.SelectedServiceIds ?? new List<string>();
            return a.Concat(b).Where(x => !string.IsNullOrWhiteSpace(x)).Select(x => x.Trim()).Distinct().ToList();
        }
        #endregion

        #region ================== 2. PUBLIC & SEARCH (HIỂN THỊ TOUR) ==================
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> SearchSuggestions(string term)
        {
            if (string.IsNullOrWhiteSpace(term)) return Json(new List<object>());

            term = term.Trim().ToLower();

            var tours = await _context.Tours
                .Where(t => !t.IsHidden && t.TrangThai == "DaDuyet" &&
                            ((t.TenTour != null && t.TenTour.ToLower().Contains(term)) ||
                             (t.DiaDiem != null && t.DiaDiem.ToLower().Contains(term))))
                .Select(t => new
                {
                    id = t.MaTour,
                    label = t.TenTour ?? "Chưa có tên",
                    price = t.GiaTour.ToString("N0") + " đ",
                    image = t.HinhAnhTourUrl
                })
                .Take(5)
                .ToListAsync();

            return Json(tours);
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index(
            string? keyword, string? sort, string? diaDiem, string? noiKhoiHanh,
            decimal? minPrice, decimal? maxPrice)
        {
            var query = _context.Tours.AsQueryable();

            if (!IsAdminOrStaff)
            {
                query = query.Where(t => !t.IsHidden && t.TrangThai == "DaDuyet");
            }

            if (!string.IsNullOrWhiteSpace(keyword))
            {
                keyword = keyword.Trim();
                ViewBag.CurrentKeyword = keyword;
                query = query.Where(t => (t.TenTour != null && t.TenTour.Contains(keyword)) ||
                                         (t.DiaDiem != null && t.DiaDiem.Contains(keyword)) ||
                                         (t.MoTa != null && t.MoTa.Contains(keyword)));
            }

            if (!string.IsNullOrEmpty(diaDiem)) query = query.Where(t => t.DiaDiem == diaDiem);
            if (!string.IsNullOrEmpty(noiKhoiHanh)) query = query.Where(t => t.NoiKhoiHanh == noiKhoiHanh);
            if (minPrice.HasValue) query = query.Where(t => t.GiaTour >= minPrice.Value);
            if (maxPrice.HasValue) query = query.Where(t => t.GiaTour <= maxPrice.Value);

            switch (sort)
            {
                case "price_asc": query = query.OrderBy(t => t.GiaTour); break;
                case "price_desc": query = query.OrderByDescending(t => t.GiaTour); break;
                case "date": query = query.OrderBy(t => t.NgayDi); break;
                case "popular": query = query.OrderByDescending(t => t.SoNguoiHienTai); break;
                default: query = query.OrderByDescending(t => t.NgayTao); break;
            }

            ViewBag.DiaDiemList = await _context.Tours
                .Where(t => !t.IsHidden && t.DiaDiem != null)
                .Select(t => t.DiaDiem)
                .Distinct()
                .ToListAsync();

            ViewBag.SortOrder = sort;

            return View(await query.ToListAsync());
        }

        [AllowAnonymous]
        public async Task<IActionResult> Details(string id)
        {
            if (string.IsNullOrEmpty(id)) return BadRequest();

            var tour = await _context.Tours
                .Include(t => t.TourDichVus).ThenInclude(td => td.DichVu)
                .Include(t => t.User)
                .FirstOrDefaultAsync(m => m.MaTour == id);

            if (tour == null) return NotFound();

            var currentUserId = _userManager.GetUserId(User);
            bool isOwner = isAuthenticated() && tour.UserId == currentUserId;

            if (tour.IsHidden && !IsAdminOrStaff && !isOwner)
            {
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Reviews = await _context.DanhGiaTours
                .Include(r => r.User)
                .Where(r => r.TourId == id)
                .OrderByDescending(r => r.NgayDanhGia)
                .Take(5)
                .ToListAsync();

            return View(tour);
        }

        private bool isAuthenticated() => User.Identity?.IsAuthenticated ?? false;
        #endregion

        #region ================== 3. BOOKING FLOW (QUY TRÌNH ĐẶT TOUR) ==================

        // GET: Hiển thị form đăng ký
        public async Task<IActionResult> Register(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var tour = await _context.Tours.FindAsync(id);
            if (tour == null || (tour.IsHidden && !IsAdminOrStaff)) return NotFound();

            // Kiểm tra full chỗ
            if (tour.SoNguoiToiDa.HasValue && tour.SoNguoiHienTai >= tour.SoNguoiToiDa)
            {
                TempData["Error"] = "Rất tiếc, Tour này đã hết chỗ!";
                return RedirectToAction(nameof(Details), new { id = id });
            }

            var user = await _userManager.GetUserAsync(User);

            // Khởi tạo Model để hiển thị
            var model = new TourRegisterViewModel
            {
                TourId = tour.MaTour,
                MaTour = tour.MaTour,
                TenTour = tour.TenTour ?? "",
                GiaTour = tour.GiaTour,
                HinhAnhTourUrl = tour.HinhAnhTourUrl,
                NgayDi = tour.NgayDi,
                DiaDiem = tour.DiaDiem,

                // Điền sẵn thông tin nếu user đã đăng nhập
                HoTenDaiDien = user?.HoTen ?? "",
                Email = user?.Email ?? "",
                SoDienThoai = user?.PhoneNumber ?? "",
                CCCD = user?.CCCD ?? "",
                NgaySinh = user?.NgaySinh, // Map ngày sinh từ user

                // Mặc định
                SoNguoiLon = 1,
                SoTreEm = 0
            };

            // Tính tạm tính ban đầu
            model.TongTienDuKien = tour.GiaTour;

            return View(model);
        }

        // POST: Xử lý khi nhấn "Xác nhận và Tiếp tục"
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(TourRegisterViewModel model)
        {
            // 1. Lấy thông tin Tour gốc
            var tour = await _context.Tours.FindAsync(model.TourId);
            if (tour == null) return NotFound();

            // 2. Xử lý Upload ảnh CCCD (Đây là phần quan trọng để fix lỗi)
            string? duongDanAnhCCCD = null;
            if (model.AnhCCCDFile != null)
            {
                // Upload vào thư mục 'cccd'
                duongDanAnhCCCD = await UploadFile(model.AnhCCCDFile, "cccd");

                if (duongDanAnhCCCD == null)
                {
                    ModelState.AddModelError("AnhCCCDFile", "Lỗi khi lưu ảnh. Vui lòng thử lại.");
                }
            }
            else
            {
                // Bắt buộc phải có ảnh (vì Model có [Required])
                ModelState.AddModelError("AnhCCCDFile", "Vui lòng chọn ảnh CCCD.");
            }

            // 3. Kiểm tra Validation (Bao gồm tuổi 16+, SĐT 10 số...)
            if (ModelState.IsValid)
            {
                // Tính toán lại tổng tiền (Logic: NL 100% + TE 70%)
                decimal giaTour = tour.GiaTour;
                decimal tongTien = (model.SoNguoiLon * giaTour) + (model.SoTreEm * giaTour * 0.7m);

                // Chuyển hướng sang trang Thanh Toán kèm dữ liệu
                // Dữ liệu này sẽ được hứng bởi ThanhToansController.BatDauThanhToan
                return RedirectToAction("BatDauThanhToan", "ThanhToans", new
                {
                    tourId = model.TourId,
                    slNguoiLon = model.SoNguoiLon,
                    slTreEm = model.SoTreEm,
                    hoTen = model.HoTenDaiDien,
                    soDienThoai = model.SoDienThoai, // ✅ đúng tên param
                    email = model.Email,
                    cccd = model.CCCD,
                    diaChi = model.DiaChiLienHe,
                    ghiChu = model.GhiChu,
                    ngaySinh = model.NgaySinh?.ToString("yyyy-MM-dd"), // Truyền ngày sinh
                    anhCCCD = duongDanAnhCCCD // Truyền đường dẫn ảnh sang bước sau
                });
            }

            // --- NẾU CÓ LỖI (Trang bị reload) ---
            // Phải nạp lại thông tin hiển thị của Tour (Vì HTTP Post không lưu các field hiển thị)
            model.TenTour = tour.TenTour ?? "";
            model.MaTour = tour.MaTour;
            model.HinhAnhTourUrl = tour.HinhAnhTourUrl;
            model.DiaDiem = tour.DiaDiem;
            model.GiaTour = tour.GiaTour;
            model.NgayDi = tour.NgayDi;

            // Tính lại giá dự kiến để hiển thị đúng
            model.TongTienDuKien = (model.SoNguoiLon * tour.GiaTour) + (model.SoTreEm * tour.GiaTour * 0.7m);

            return View(model);
        }
        #endregion

        [Authorize(Roles = "User")]
        public async Task<IActionResult> CreatePersonal()
        {
            // 1. Lấy danh sách từ khóa tỉnh thành từ DB
            ViewBag.Keywords = await _context.DiaDiems
                .Select(d => d.TenDiaDiem)
                .Distinct()
                .ToListAsync() ?? new List<string>();

            // 2. Lấy danh sách Tour mẫu hệ thống
            ViewBag.DefaultTours = await _context.Tours
                .Where(t => t.IsDefault && !t.IsHidden)
                .ToListAsync() ?? new List<Tour>();

            // 3. Lấy danh sách dịch vụ kèm địa điểm liên kết
            ViewBag.DichVuList = await _context.DichVus
                .Include(d => d.DiaDiem)
                .OrderBy(d => d.TenDichVu)
                .ToListAsync() ?? new List<DichVu>();

            return View(new Tour
            {
                IsPersonal = true,
                TrangThai = "ChoDuyet",
                SoNguoiToiDa = 2,
                NgayDi = DateTime.Now.AddDays(7),
                NgayVe = DateTime.Now.AddDays(10)
            });
        }

        [HttpPost]
        [Authorize(Roles = "User")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreatePersonal(Tour tour, string[] SelectedServices)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();

            ModelState.Remove(nameof(tour.MaTour));
            ModelState.Remove(nameof(tour.UserId));
            ModelState.Remove(nameof(tour.TrangThai));
            ModelState.Remove(nameof(tour.User));

            if (ModelState.IsValid)
            {
                try
                {
                    tour.MaTour = MaSoHelper.TaoMa("P");
                    tour.UserId = user.Id;
                    tour.TrangThai = "ChoDuyet";
                    tour.IsPersonal = true;
                    tour.NgayTao = DateTime.Now;

                    _context.Add(tour);
                    await _context.SaveChangesAsync();

                    if (SelectedServices != null && SelectedServices.Any())
                    {
                        foreach (var sId in SelectedServices)
                        {
                            _context.TourDichVus.Add(new TourDichVu { TourId = tour.MaTour, DichVuId = sId });
                        }
                        await _context.SaveChangesAsync();
                    }
                    TempData["Success"] = "Yêu cầu đã được gửi!";
                    return RedirectToAction(nameof(Custom));
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "Lỗi hệ thống: " + ex.Message);
                }
            }
            // Nạp lại dữ liệu nếu form lỗi
            ViewBag.Keywords = await _context.DiaDiems.Select(d => d.TenDiaDiem).Distinct().ToListAsync();
            ViewBag.DichVuList = await _context.DichVus.Include(d => d.DiaDiem).ToListAsync();
            return View(tour);
        }

        // Action bổ sung: Copy một tour mẫu thành tour cá nhân
        [HttpPost]
        [Authorize(Roles = "User")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CloneToPersonal(string id)
        {
            var user = await _userManager.GetUserAsync(User);
            var originalTour = await _context.Tours.Include(t => t.TourDichVus).FirstOrDefaultAsync(t => t.MaTour == id);

            if (originalTour == null) return NotFound();

            var personalTour = new Tour
            {
                MaTour = MaSoHelper.TaoMa("P"),
                TenTour = "Tùy chỉnh: " + originalTour.TenTour,
                DiaDiem = originalTour.DiaDiem,
                NoiKhoiHanh = originalTour.NoiKhoiHanh,
                MoTa = originalTour.MoTa,
                GiaTour = originalTour.GiaTour,
                NgayDi = originalTour.NgayDi,
                NgayVe = originalTour.NgayVe,
                UserId = user.Id,
                IsPersonal = true,
                TrangThai = "ChoDuyet",
                NgayTao = DateTime.Now,
                IsHidden = true
            };

            _context.Tours.Add(personalTour);
            await _context.SaveChangesAsync();

            foreach (var dv in originalTour.TourDichVus)
            {
                _context.TourDichVus.Add(new TourDichVu { TourId = personalTour.MaTour, DichVuId = dv.DichVuId });
            }
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Custom));
        }

        [Authorize(Roles = "User")]
        public async Task<IActionResult> Custom()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();

            var myTours = await _context.Tours
                .Where(t => t.UserId == user.Id && t.IsPersonal)
                .OrderByDescending(t => t.NgayTao)
                .ToListAsync();

            return View(myTours);
        }

        [Authorize(Roles = "User")]
        public async Task<IActionResult> EditPersonal(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var user = await _userManager.GetUserAsync(User);
            var tour = await _context.Tours.FirstOrDefaultAsync(t => t.MaTour == id && t.UserId == user.Id);

            if (tour == null) return NotFound();

            if (tour.TrangThai != "ChoDuyet")
            {
                TempData["Error"] = "Tour này đã được xử lý hoặc hủy, không thể chỉnh sửa.";
                return RedirectToAction(nameof(Custom));
            }

            return View(tour);
        }

        [HttpPost]
        [Authorize(Roles = "User")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditPersonal(string id, Tour tour)
        {
            if (id != tour.MaTour) return NotFound();

            var user = await _userManager.GetUserAsync(User);
            var existingTour = await _context.Tours.FirstOrDefaultAsync(t => t.MaTour == id && t.UserId == user.Id);

            if (existingTour == null) return NotFound();

            if (ModelState.IsValid)
            {
                existingTour.TenTour = tour.TenTour;
                existingTour.DiaDiem = tour.DiaDiem;
                existingTour.NgayDi = tour.NgayDi;
                existingTour.NgayVe = tour.NgayVe;
                existingTour.SoNguoiToiDa = tour.SoNguoiToiDa;
                existingTour.MoTa = tour.MoTa;
                existingTour.YeuCauKhachSan = tour.YeuCauKhachSan;
                existingTour.YeuCauNhaHang = tour.YeuCauNhaHang;
                existingTour.YeuCauPhuongTien = tour.YeuCauPhuongTien;
                existingTour.YeuCauVuiChoi = tour.YeuCauVuiChoi;
                existingTour.YeuCauKhac = tour.YeuCauKhac;
                existingTour.NgayTao = DateTime.Now;

                try
                {
                    _context.Update(existingTour);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = "Cập nhật yêu cầu thành công!";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TourExists(tour.MaTour)) return NotFound();
                    throw;
                }

                return RedirectToAction(nameof(Custom));
            }

            return View(tour);
        }

        #region ================== 5. ADMIN SYSTEM MANAGEMENT (QUẢN LÝ TOUR) ==================
        [Authorize(Roles = "Admin,Staff")]
        public async Task<IActionResult> Create()
        {
            var vm = new TourCreateViewModel
            {
                MaTour = MaSoHelper.TaoMa("T"),
                NgayDi = DateTime.Now.AddDays(10),
                NgayVe = DateTime.Now.AddDays(15),
                SoNguoiToiDa = 20
            };

            await LoadTourCreateDataAsync(vm);
            return View(vm);
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Staff")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TourCreateViewModel model, IFormFile? AnhTourFile)
        {
            if (string.IsNullOrEmpty(model.MaTour)) model.MaTour = MaSoHelper.TaoMa("T");

            if (!ModelState.IsValid)
            {
                await LoadTourCreateDataAsync(model);
                return View(model);
            }

            var tour = new Tour
            {
                MaTour = model.MaTour,
                TenTour = model.TenTour,
                LoaiTour = model.LoaiTour,
                NoiKhoiHanh = model.NoiKhoiHanh,
                DiaDiem = model.DiaDiem,
                MoTa = model.MoTa,
                GiaTour = model.GiaTour,
                SoNguoiToiDa = model.SoNguoiToiDa,
                SoNguoiHienTai = 0,
                NgayDi = model.NgayDi,
                NgayVe = model.NgayVe,
                IsDefault = true,
                IsPersonal = false,
                IsHidden = false,
                TrangThai = "DaDuyet",
                NgayTao = DateTime.Now
            };

            // Upload ảnh tour (Dùng chung hàm UploadFile, thư mục 'tours')
            tour.HinhAnhTourUrl = await UploadFile(AnhTourFile, "tours");

            _context.Add(tour);
            await _context.SaveChangesAsync();

            // ====== [FIX] LƯU DỊCH VỤ ĐI KÈM: bind đúng name SelectedDichVuIds/SelectedServiceIds ======
            var selectedIds = GetSelectedDichVuIdsUnified(model);
            if (selectedIds.Any())
            {
                foreach (var sid in selectedIds)
                {
                    _context.TourDichVus.Add(new TourDichVu
                    {
                        TourId = tour.MaTour,
                        DichVuId = sid // nên là MaTenDichVu (đang sync = MaDichVu)
                    });
                }
                await _context.SaveChangesAsync();
            }

            TempData["Success"] = "Đã tạo Tour hệ thống thành công!";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin,Staff")]
        public async Task<IActionResult> Edit(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var tour = await _context.Tours
                .Include(t => t.TourDichVus)
                .FirstOrDefaultAsync(t => t.MaTour == id);

            if (tour == null) return NotFound();

            var vm = new TourCreateViewModel
            {
                MaTour = tour.MaTour,
                TenTour = tour.TenTour ?? "",
                LoaiTour = tour.LoaiTour ?? "",
                NoiKhoiHanh = tour.NoiKhoiHanh ?? "",
                DiaDiem = tour.DiaDiem ?? "",
                MoTa = tour.MoTa ?? "",
                GiaTour = tour.GiaTour,
                SoNguoiToiDa = tour.SoNguoiToiDa ?? 0,
                SoNguoiHienTai = tour.SoNguoiHienTai.GetValueOrDefault(),
                NgayDi = tour.NgayDi ?? DateTime.Now,
                NgayVe = tour.NgayVe ?? DateTime.Now,
                HinhAnhTourUrl = tour.HinhAnhTourUrl
            };

            // ====== [FIX] ĐỔ DỊCH VỤ ĐÃ CHỌN ======
            var existed = tour.TourDichVus.Select(td => td.DichVuId).ToList();
            vm.SelectedDichVuIds = existed;
            vm.SelectedServiceIds = existed; // giữ lại để đồng bộ (không xóa)

            ViewBag.CurrentImg = tour.HinhAnhTourUrl;

            await LoadTourCreateDataAsync(vm);
            return View(vm);
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Staff")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, TourCreateViewModel model, IFormFile? AnhTourFile)
        {
            if (id != model.MaTour) return NotFound();

            if (!ModelState.IsValid)
            {
                ViewBag.CurrentImg = model.HinhAnhTourUrl;
                await LoadTourCreateDataAsync(model);
                return View(model);
            }

            try
            {
                var tourDb = await _context.Tours
                    .Include(t => t.TourDichVus)
                    .FirstOrDefaultAsync(t => t.MaTour == id);

                if (tourDb == null) return NotFound();

                tourDb.TenTour = model.TenTour;
                tourDb.LoaiTour = model.LoaiTour;
                tourDb.NoiKhoiHanh = model.NoiKhoiHanh;
                tourDb.DiaDiem = model.DiaDiem;
                tourDb.MoTa = model.MoTa;
                tourDb.GiaTour = model.GiaTour;
                tourDb.SoNguoiToiDa = model.SoNguoiToiDa;
                tourDb.NgayDi = model.NgayDi;
                tourDb.NgayVe = model.NgayVe;

                if (AnhTourFile != null)
                {
                    DeleteOldImage(tourDb.HinhAnhTourUrl);
                    // Upload ảnh mới vào thư mục 'tours'
                    tourDb.HinhAnhTourUrl = await UploadFile(AnhTourFile, "tours");
                }

                // ====== [FIX] REFRESH SERVICES ======
                if (tourDb.TourDichVus != null && tourDb.TourDichVus.Any())
                {
                    _context.TourDichVus.RemoveRange(tourDb.TourDichVus);
                }

                var selectedIds = GetSelectedDichVuIdsUnified(model);
                if (selectedIds.Any())
                {
                    foreach (var sid in selectedIds)
                    {
                        _context.TourDichVus.Add(new TourDichVu
                        {
                            TourId = id,
                            DichVuId = sid
                        });
                    }
                }

                _context.Update(tourDb);
                await _context.SaveChangesAsync();

                TempData["Success"] = "Cập nhật Tour thành công!";
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TourExists(model.MaTour ?? "")) return NotFound();
                throw;
            }

            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var tour = await _context.Tours.FirstOrDefaultAsync(m => m.MaTour == id);
            if (tour == null) return NotFound();

            var hasOrders = await _context.GiaoDiches.AnyAsync(g => g.TourId == id);
            if (hasOrders)
            {
                TempData["Error"] = "Không thể xóa Tour đã có giao dịch phát sinh. Hãy ẩn tour đi.";
                return RedirectToAction(nameof(Index));
            }

            return View(tour);
        }

        [HttpPost, ActionName("Delete")]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var tour = await _context.Tours.FindAsync(id);
            if (tour != null)
            {
                var hasOrders = await _context.GiaoDiches.AnyAsync(g => g.TourId == id);
                if (hasOrders)
                {
                    TempData["Error"] = "Không thể xóa tour đã có booking.";
                    return RedirectToAction(nameof(Index));
                }

                DeleteOldImage(tour.HinhAnhTourUrl);
                _context.Tours.Remove(tour);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Đã xóa Tour vĩnh viễn.";
            }

            return RedirectToAction(nameof(Index));
        }
        #endregion

        #region ================== 6. ADMIN APPROVAL (DUYỆT TOUR CÁ NHÂN) ==================
        [Authorize(Roles = "Admin,Staff")]
        public async Task<IActionResult> PendingPersonalList()
        {
            var pendingTours = await _context.Tours
                .Include(t => t.User)
                .Where(t => t.IsPersonal && t.TrangThai == "ChoDuyet")
                .OrderByDescending(t => t.NgayTao)
                .ToListAsync();

            return View(pendingTours);
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Staff")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApprovePersonal(string id, decimal giaTour, string? adminNote)
        {
            var tour = await _context.Tours.FindAsync(id);
            if (tour == null) return NotFound();

            if (giaTour <= 0)
            {
                TempData["Error"] = "Vui lòng nhập giá tour hợp lệ.";
                return RedirectToAction(nameof(Index));
            }

            tour.TrangThai = "DaDuyet";
            tour.GiaTour = giaTour;
            tour.IsHidden = false; // Hiện lên để khách thấy và thanh toán

            if (!string.IsNullOrEmpty(adminNote))
            {
                tour.MoTa += $"\n[Admin Note]: {adminNote}";
            }

            await _context.SaveChangesAsync();

            TempData["Success"] = $"Đã duyệt tour {tour.MaTour} và báo giá {giaTour:N0}đ thành công!";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [Authorize(Roles = "Admin,Staff")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RejectPersonal(string id, string lyDo)
        {
            var tour = await _context.Tours.FindAsync(id);
            if (tour == null) return NotFound();

            tour.TrangThai = "TuChoi";
            tour.MoTa += $"\n[Lý do từ chối]: {lyDo}";
            tour.IsHidden = true;

            await _context.SaveChangesAsync();

            TempData["Message"] = "Đã từ chối yêu cầu tour.";
            return RedirectToAction(nameof(Index));
        }
        #endregion

        public async Task<IActionResult> ToggleHide(string id)
        {
            if (id == null) return NotFound();

            var tour = await _context.Tours.FindAsync(id);
            if (tour == null) return NotFound();

            tour.IsHidden = !tour.IsHidden;

            _context.Update(tour);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        private bool TourExists(string id)
        {
            return _context.Tours.Any(e => e.MaTour == id);
        }
    }
}

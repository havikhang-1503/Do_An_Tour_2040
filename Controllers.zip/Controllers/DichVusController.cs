﻿// Folder: Controllers
// File path: Controllers/DichVusController.cs

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Tour_2040.Data;
using Tour_2040.Models;
using Tour_2040.Utils;

namespace Tour_2040.Controllers
{
    [Authorize]
    public class DichVusController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _env;

        public DichVusController(ApplicationDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        // Các loại dịch vụ BẮT BUỘC phải chọn địa điểm
        private static readonly string[] LOAI_CAN_DIA_DIEM =
        {
            "Phương tiện",
            "Nhà hàng",
            "Khách sạn",
            "Khu vui chơi"
        };

        private bool LoaiCanDiaDiem(string? loai)
            => !string.IsNullOrWhiteSpace(loai) && LOAI_CAN_DIA_DIEM.Contains(loai);

        // Dropdown địa điểm: hiển thị TenDiaDiem - XaPhuong - Tinh
        private void LoadDiaDiemDropdown(string? selectedMa = null)
        {
            var list = _context.DiaDiems
                .Include(d => d.XaPhuong)
                    .ThenInclude(xp => xp!.TinhThanh)
                .OrderBy(d => d.XaPhuong!.TinhThanh!.TenTinh)
                .ThenBy(d => d.XaPhuong!.TenXaPhuong)
                .ThenBy(d => d.TenDiaDiem)
                .Select(d => new
                {
                    MaDiaDiem = d.MaDiaDiem,
                    TenHienThi = $"{d.TenDiaDiem} - {d.XaPhuong!.TenXaPhuong} - {d.XaPhuong!.TinhThanh!.TenTinh}"
                })
                .ToList();

            ViewData["MaDiaDiem"] = new SelectList(list, "MaDiaDiem", "TenHienThi", selectedMa);
        }

        // GET: DichVus
        [AllowAnonymous]
        public async Task<IActionResult> Index(string? searchString, string? loai, string? trangThai)
        {
            ViewData["CurrentFilter"] = searchString;
            ViewData["LoaiFilter"] = loai;
            ViewData["TrangThaiFilter"] = trangThai;

            var query = _context.DichVus
                .Include(d => d.DiaDiem)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                query = query.Where(s =>
                    s.TenDichVu.Contains(searchString) ||
                    s.MaDichVu.Contains(searchString) ||
                    (s.DiaDiem != null && s.DiaDiem.TenDiaDiem.Contains(searchString)));
            }

            if (!string.IsNullOrWhiteSpace(loai))
                query = query.Where(d => d.LoaiDichVu == loai);

            if (!string.IsNullOrWhiteSpace(trangThai))
                query = query.Where(d => d.TrangThai == trangThai);

            var list = await query
                .OrderBy(d => d.MaTenDichVu)
                .ToListAsync();

            return View(list);
        }

        // GET: DichVus/Create
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            LoadDiaDiemDropdown();

            var model = new DichVu
            {
                MaDichVu = MaSoHelper.TaoMa("MDV"),
                MaTenDichVu = "",
                TrangThai = "Active",
                HieuLucTu = DateTime.Now
            };

            return View(model);
        }

        // POST: DichVus/Create
        [HttpPost]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DichVu model, IFormFile? HinhAnhFile)
        {
            // auto code
            if (string.IsNullOrWhiteSpace(model.MaDichVu))
                model.MaDichVu = MaSoHelper.TaoMa("MDV");

            // sync PK
            model.MaTenDichVu = model.MaDichVu;

            // validate địa điểm theo loại
            if (LoaiCanDiaDiem(model.LoaiDichVu))
            {
                if (string.IsNullOrWhiteSpace(model.MaDiaDiem))
                    ModelState.AddModelError(nameof(DichVu.MaDiaDiem), "Loại dịch vụ này bắt buộc phải chọn Địa điểm.");
            }
            else
            {
                // loại không cần địa điểm thì ép null cho sạch DB
                model.MaDiaDiem = null;
            }

            // dup
            if (await _context.DichVus.AnyAsync(d => d.MaTenDichVu == model.MaTenDichVu))
                ModelState.AddModelError(nameof(DichVu.MaDichVu), "Mã dịch vụ này đã tồn tại.");

            if (ModelState.IsValid)
            {
                if (HinhAnhFile != null && HinhAnhFile.Length > 0)
                {
                    var fileName = $"{Guid.NewGuid()}{Path.GetExtension(HinhAnhFile.FileName)}";
                    var uploadsFolder = Path.Combine(_env.WebRootPath, "images", "dichvu");
                    Directory.CreateDirectory(uploadsFolder);

                    var filePath = Path.Combine(uploadsFolder, fileName);
                    using var stream = new FileStream(filePath, FileMode.Create);
                    await HinhAnhFile.CopyToAsync(stream);

                    model.HinhAnhUrl = $"/images/dichvu/{fileName}";
                }

                _context.Add(model);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            LoadDiaDiemDropdown(model.MaDiaDiem);
            return View(model);
        }

        // GET: DichVus/Edit/ID
        [Authorize(Roles = "Admin,Staff")]
        public async Task<IActionResult> Edit(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();

            var dichVu = await _context.DichVus.FindAsync(id);
            if (dichVu == null) return NotFound();

            LoadDiaDiemDropdown(dichVu.MaDiaDiem);
            return View(dichVu);
        }

        // POST: DichVus/Edit/ID
        [HttpPost]
        [Authorize(Roles = "Admin,Staff")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, DichVu model, IFormFile? HinhAnhFile)
        {
            if (id != model.MaTenDichVu) return NotFound();

            // validate địa điểm theo loại
            if (LoaiCanDiaDiem(model.LoaiDichVu))
            {
                if (string.IsNullOrWhiteSpace(model.MaDiaDiem))
                    ModelState.AddModelError(nameof(DichVu.MaDiaDiem), "Loại dịch vụ này bắt buộc phải chọn Địa điểm.");
            }
            else
            {
                model.MaDiaDiem = null;
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (HinhAnhFile != null && HinhAnhFile.Length > 0)
                    {
                        var fileName = $"{Guid.NewGuid()}{Path.GetExtension(HinhAnhFile.FileName)}";
                        var uploadsFolder = Path.Combine(_env.WebRootPath, "images", "dichvu");
                        Directory.CreateDirectory(uploadsFolder);

                        var filePath = Path.Combine(uploadsFolder, fileName);
                        using var stream = new FileStream(filePath, FileMode.Create);
                        await HinhAnhFile.CopyToAsync(stream);

                        model.HinhAnhUrl = $"/images/dichvu/{fileName}";
                    }
                    else
                    {
                        // giữ ảnh cũ
                        var old = await _context.DichVus.AsNoTracking()
                            .FirstOrDefaultAsync(x => x.MaTenDichVu == id);

                        if (old != null) model.HinhAnhUrl = old.HinhAnhUrl;
                    }

                    _context.Update(model);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DichVuExists(model.MaTenDichVu)) return NotFound();
                    throw;
                }

                return RedirectToAction(nameof(Index));
            }

            LoadDiaDiemDropdown(model.MaDiaDiem);
            return View(model);
        }

        // GET: DichVus/Details/ID
        [AllowAnonymous]
        public async Task<IActionResult> Details(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();

            var dichVu = await _context.DichVus
                .Include(d => d.DiaDiem)
                    .ThenInclude(dd => dd!.XaPhuong)
                        .ThenInclude(xp => xp!.TinhThanh)
                .FirstOrDefaultAsync(d => d.MaTenDichVu == id);

            if (dichVu == null) return NotFound();

            return View(dichVu);
        }

        // GET: DichVus/Delete/ID
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return NotFound();

            var dichVu = await _context.DichVus
                .Include(d => d.DiaDiem)
                .FirstOrDefaultAsync(m => m.MaTenDichVu == id);

            if (dichVu == null) return NotFound();

            return View(dichVu);
        }

        // POST: DichVus/Delete/ID
        [HttpPost, ActionName("Delete")]
        [Authorize(Roles = "Admin")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var dichVu = await _context.DichVus.FindAsync(id);
            if (dichVu != null)
            {
                _context.DichVus.Remove(dichVu);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool DichVuExists(string id)
            => _context.DichVus.Any(e => e.MaTenDichVu == id);
    }
}

﻿// Folder: Controllers
// File path: Controllers/DanhGiaToursController.cs

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Tour_2040.Data;
using Tour_2040.Models;
using Tour_2040.Utils; // For MaSoHelper

namespace Tour_2040.Controllers
{
    [Authorize]
    public class DanhGiaToursController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IWebHostEnvironment _env;

        public DanhGiaToursController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager,
            IWebHostEnvironment env)
        {
            _context = context;
            _userManager = userManager;
            _env = env;
        }

        // ==============================
        // LIST
        // ==============================
        [AllowAnonymous]
        public async Task<IActionResult> Index(string? lichTrinhId, string? tourId)
        {
            var query = _context.DanhGiaTours
                .Include(d => d.User)
                .Include(d => d.LichTrinh)
                .ThenInclude(l => l.Tour)
                .AsQueryable();

            if (!string.IsNullOrEmpty(lichTrinhId))
            {
                query = query.Where(d => d.LichTrinhId == lichTrinhId);
            }

            if (!string.IsNullOrEmpty(tourId))
            {
                query = query.Where(d => d.TourId == tourId);
            }

            var list = await query
                .OrderByDescending(d => d.NgayTao)
                .Select(d => new DanhGiaTourItemViewModel
                {
                    Id = d.MaDanhGia, // String ID
                    LichTrinhId = d.LichTrinhId,
                    TourId = d.TourId,
                    UserId = d.UserId,
                    TenNguoiDung = d.User != null ? d.User.HoTen : "Khách",
                    SoSao = d.SoSao,
                    BinhLuan = d.BinhLuan,
                    HinhAnhUrl = d.HinhAnhUrl,
                    NgayTao = d.NgayTao
                })
                .ToListAsync();

            return View(list);
        }

        // ==============================
        // GET: CREATE (String lichTrinhId)
        // ==============================
        [HttpGet]
        public async Task<IActionResult> Create(string lichTrinhId)
        {
            if (string.IsNullOrEmpty(lichTrinhId)) return NotFound();

            var lichTrinh = await _context.LichTrinhs
                .Include(l => l.Tour)
                .FirstOrDefaultAsync(l => l.MaLichTrinh == lichTrinhId); // String Match

            if (lichTrinh == null) return NotFound();

            string tenTour = lichTrinh.Tour?.TenTour ?? $"Lịch trình {lichTrinhId}";

            var danhGias = await _context.DanhGiaTours
                .Where(d => d.LichTrinhId == lichTrinhId)
                .Include(d => d.User)
                .OrderByDescending(d => d.NgayTao)
                .Select(d => new DanhGiaTourItemViewModel
                {
                    Id = d.MaDanhGia,
                    LichTrinhId = d.LichTrinhId,
                    TourId = d.TourId,
                    UserId = d.UserId,
                    TenNguoiDung = d.User != null ? d.User.HoTen : "Khách",
                    SoSao = d.SoSao,
                    BinhLuan = d.BinhLuan,
                    HinhAnhUrl = d.HinhAnhUrl,
                    NgayTao = d.NgayTao
                })
                .ToListAsync();

            var vm = new DanhGiaTourCreateViewModel
            {
                LichTrinhId = lichTrinhId,
                TenTourHoacLichTrinh = tenTour,
                SoSao = 5,
                DanhGias = danhGias
            };

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DanhGiaTourCreateViewModel model)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();

            if (ModelState.IsValid)
            {
                string? imageUrl = null;
                if (model.HinhAnhFile != null && model.HinhAnhFile.Length > 0)
                {
                    imageUrl = await SaveImageAsync(model.HinhAnhFile);
                }

                // Use MaSoHelper for consistent ID generation
                string maDanhGia = MaSoHelper.TaoMa("MDG");

                // Get TourId from LichTrinh
                var lichTrinh = await _context.LichTrinhs.FindAsync(model.LichTrinhId);

                var entity = new DanhGiaTour
                {
                    MaDanhGia = maDanhGia,
                    LichTrinhId = model.LichTrinhId,
                    TourId = lichTrinh?.TourId,
                    UserId = user.Id,
                    SoSao = model.SoSao,
                    BinhLuan = model.BinhLuan,
                    HinhAnhUrl = imageUrl,
                    NgayTao = DateTime.Now,
                    NgayDanhGia = DateTime.Now
                };

                _context.DanhGiaTours.Add(entity);
                await _context.SaveChangesAsync();

                TempData["DanhGiaMessage"] = "Cảm ơn bạn đã đánh giá!";
                return RedirectToAction(nameof(Create), new { lichTrinhId = model.LichTrinhId });
            }
            return View(model);
        }

        // ==============================
        // EDIT (String ID)
        // ==============================
        [HttpGet]
        public async Task<IActionResult> Edit(string id)
        {
            var entity = await _context.DanhGiaTours
                .Include(d => d.LichTrinh).ThenInclude(l => l.Tour)
                .FirstOrDefaultAsync(d => d.MaDanhGia == id);

            if (entity == null) return NotFound();

            var user = await _userManager.GetUserAsync(User);
            if (user == null || entity.UserId != user.Id) return Forbid();

            var vm = new DanhGiaTourEditViewModel
            {
                Id = entity.MaDanhGia,
                LichTrinhId = entity.LichTrinhId,
                TenTourHoacLichTrinh = entity.LichTrinh?.Tour?.TenTour ?? "Tour",
                SoSao = entity.SoSao,
                BinhLuan = entity.BinhLuan,
                HinhAnhUrl = entity.HinhAnhUrl
            };

            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, DanhGiaTourEditViewModel model)
        {
            if (id != model.Id) return NotFound();

            var entity = await _context.DanhGiaTours.FindAsync(id);
            if (entity == null) return NotFound();

            var user = await _userManager.GetUserAsync(User);
            if (user == null || entity.UserId != user.Id) return Forbid();

            if (ModelState.IsValid)
            {
                entity.SoSao = model.SoSao;
                entity.BinhLuan = model.BinhLuan;
                entity.NgayCapNhat = DateTime.Now;

                if (model.HinhAnhFile != null)
                {
                    entity.HinhAnhUrl = await SaveImageAsync(model.HinhAnhFile);
                }

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Create), new { lichTrinhId = entity.LichTrinhId });
            }
            return View(model);
        }

        // ==============================
        // DELETE (String ID)
        // ==============================
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var d = await _context.DanhGiaTours.FindAsync(id);
            if (d == null) return NotFound();

            var user = await _userManager.GetUserAsync(User);
            if (user == null || d.UserId != user.Id) return Forbid();

            _context.DanhGiaTours.Remove(d);
            await _context.SaveChangesAsync();

            // Return to previous list context if possible, otherwise Index
            return RedirectToAction(nameof(Index));
        }

        private async Task<string> SaveImageAsync(Microsoft.AspNetCore.Http.IFormFile file)
        {
            var uploadsFolder = Path.Combine(_env.WebRootPath, "uploads", "danhgia");
            if (!Directory.Exists(uploadsFolder)) Directory.CreateDirectory(uploadsFolder);

            var fileName = $"{Guid.NewGuid()}{Path.GetExtension(file.FileName)}";
            var filePath = Path.Combine(uploadsFolder, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(stream);
            }
            return $"/uploads/danhgia/{fileName}";
        }
    }
}
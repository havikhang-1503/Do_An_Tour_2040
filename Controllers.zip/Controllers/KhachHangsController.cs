﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tour_2040.Data;
using Tour_2040.Models;
using Tour_2040.Utils;
using Microsoft.AspNetCore.Identity;

namespace Tour_2040.Controllers
{
    [Authorize(Roles = "Admin,Staff")]
    public class KhachHangsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public KhachHangsController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // ================== HELPER: ĐỒNG BỘ USER SANG KHÁCH HÀNG (ĐÃ FIX LỌC ROLE) ==================
        private async Task SyncUsersToCustomers()
        {
            // 1. Lấy danh sách Email hiện có trong bảng KhachHangs
            var existingEmails = await _context.KhachHangs
                                               .Select(k => k.Email)
                                               .ToListAsync();

            // 2. Lấy các User chưa có mặt trong bảng KhachHangs
            var newUsers = await _context.Users
                                         .Where(u => !existingEmails.Contains(u.Email))
                                         .ToListAsync();

            if (newUsers.Any())
            {
                foreach (var user in newUsers)
                {
                    // --- ĐOẠN CODE MỚI THÊM: CHECK ROLE ---
                    // Kiểm tra xem user này có phải Admin hoặc Staff không
                    var isAdmin = await _userManager.IsInRoleAsync(user, "Admin");
                    var isStaff = await _userManager.IsInRoleAsync(user, "Staff");

                    // Nếu là Admin hoặc Staff thì BỎ QUA (continue), không tạo khách hàng
                    if (isAdmin || isStaff)
                    {
                        continue;
                    }
                    // ---------------------------------------

                    var kh = new KhachHang
                    {
                        MaKhachHang = MaSoHelper.TaoMa("KH"),
                        MaTenKhachHang = Guid.NewGuid().ToString(), // Tạo GUID làm khóa chính

                        HoTen = user.HoTen ?? user.UserName ?? "Khách hàng mới",
                        Email = user.Email,
                        SoDienThoai = user.PhoneNumber,
                        NgayTao = DateTime.Now,
                        NhomKhach = "Thường",
                        TrangThaiTour = "Chưa đặt tour"
                    };

                    _context.KhachHangs.Add(kh);
                }
                await _context.SaveChangesAsync();
            }
        }

        // ================== LIST + FILTER ==================
        public async Task<IActionResult> Index(string? keyword, string? nhomKhach, string? trangThaiTour)
        {
            // Gọi hàm đồng bộ (đã lọc Admin/Staff)
            await SyncUsersToCustomers();

            var query = _context.KhachHangs.AsQueryable();

            if (!string.IsNullOrWhiteSpace(keyword))
            {
                var k = keyword.Trim().ToLower();
                query = query.Where(x =>
                    (x.HoTen != null && x.HoTen.ToLower().Contains(k)) ||
                    (x.MaKhachHang != null && x.MaKhachHang.ToLower().Contains(k)) ||
                    (x.Email != null && x.Email.ToLower().Contains(k)) ||
                    (x.SoDienThoai != null && x.SoDienThoai.Contains(k))
                );
            }

            if (!string.IsNullOrEmpty(nhomKhach) && nhomKhach != "All")
            {
                query = query.Where(x => x.NhomKhach == nhomKhach);
            }

            if (!string.IsNullOrEmpty(trangThaiTour) && trangThaiTour != "All")
            {
                query = query.Where(x => x.TrangThaiTour == trangThaiTour);
            }

            query = query.OrderByDescending(x => x.NgayTao);

            var list = await query.ToListAsync();

            ViewData["Keyword"] = keyword ?? "";
            ViewData["NhomKhach"] = nhomKhach ?? "All";
            ViewData["TrangThaiTour"] = trangThaiTour ?? "All";

            return View(list);
        }

        // ================== DETAILS (Đã fix lỗi 404) ==================
        public async Task<IActionResult> Details(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var kh = await _context.KhachHangs
                .FirstOrDefaultAsync(x => x.MaTenKhachHang == id || x.MaKhachHang == id);

            if (kh == null) return NotFound();

            return View(kh);
        }

        // ================== CREATE ==================
        public IActionResult Create()
        {
            var model = new KhachHang
            {
                MaKhachHang = MaSoHelper.TaoMa("KH"),
                NgayTao = DateTime.Now,
                NhomKhach = "Thường",
                TrangThaiTour = "Chưa đặt tour"
            };
            model.MaTenKhachHang = Guid.NewGuid().ToString();

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(KhachHang khachHang)
        {
            if (string.IsNullOrWhiteSpace(khachHang.MaKhachHang))
            {
                khachHang.MaKhachHang = MaSoHelper.TaoMa("KH");
            }

            if (string.IsNullOrEmpty(khachHang.MaTenKhachHang))
            {
                khachHang.MaTenKhachHang = Guid.NewGuid().ToString();
            }

            if (khachHang.NgayTao == default)
            {
                khachHang.NgayTao = DateTime.Now;
            }

            ModelState.Remove(nameof(khachHang.MaTenKhachHang));

            if (!ModelState.IsValid)
            {
                return View(khachHang);
            }

            if (await _context.KhachHangs.AnyAsync(k => k.MaKhachHang == khachHang.MaKhachHang))
            {
                ModelState.AddModelError("MaKhachHang", "Mã khách hàng này đã tồn tại.");
                return View(khachHang);
            }

            _context.KhachHangs.Add(khachHang);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // ================== EDIT (Đã fix lỗi 404) ==================
        public async Task<IActionResult> Edit(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var kh = await _context.KhachHangs
                .FirstOrDefaultAsync(x => x.MaTenKhachHang == id || x.MaKhachHang == id);

            if (kh == null) return NotFound();

            return View(kh);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, KhachHang khachHang)
        {
            if (id != khachHang.MaTenKhachHang && id != khachHang.MaKhachHang)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                return View(khachHang);
            }

            try
            {
                _context.Update(khachHang);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                var exists = await _context.KhachHangs
                    .AnyAsync(e => e.MaTenKhachHang == id || e.MaKhachHang == id);

                if (!exists) return NotFound();
                else throw;
            }

            return RedirectToAction(nameof(Index));
        }

        // ================== DELETE (Đã fix lỗi 404) ==================
        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var kh = await _context.KhachHangs
                .FirstOrDefaultAsync(x => x.MaTenKhachHang == id || x.MaKhachHang == id);

            if (kh == null) return NotFound();

            return View(kh);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var kh = await _context.KhachHangs
                .FirstOrDefaultAsync(x => x.MaTenKhachHang == id || x.MaKhachHang == id);

            if (kh != null)
            {
                var hasDependents = await _context.GiaoDiches.AnyAsync(g => g.KhachHangId == kh.MaTenKhachHang);
                if (hasDependents)
                {
                    TempData["Error"] = "Không thể xóa khách hàng đã có giao dịch.";
                    return RedirectToAction(nameof(Index));
                }

                _context.KhachHangs.Remove(kh);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
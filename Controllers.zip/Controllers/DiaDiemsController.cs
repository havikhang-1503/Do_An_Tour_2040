﻿// Folder: Controllers
// File path: Controllers/DiaDiemsController.cs

using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Tour_2040.Data;
using Tour_2040.Models;
using Tour_2040.Utils;

namespace Tour_2040.Controllers
{
    public class DiaDiemsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DiaDiemsController(ApplicationDbContext context)
        {
            _context = context;
        }

        private void LoadTinhDropdown(int? selectedTinh = null)
        {
            ViewData["TinhThanhId"] = new SelectList(
                _context.TinhThanhs.OrderBy(t => t.TenTinh),
                "MaTinhThanh",
                "TenTinh",
                selectedTinh
            );
        }

        private async Task LoadXaDropdownAsync(int? tinhThanhId, int? selectedXa = null)
        {
            if (!tinhThanhId.HasValue)
            {
                ViewData["XaPhuongId"] = new SelectList(Enumerable.Empty<SelectListItem>());
                return;
            }

            var xaList = await _context.XaPhuongs
                .Where(x => x.TinhThanhId == tinhThanhId.Value)
                .OrderBy(x => x.TenXaPhuong)
                .ToListAsync();

            ViewData["XaPhuongId"] = new SelectList(xaList, "MaXaPhuong", "TenXaPhuong", selectedXa);
        }

        // API cho dropdown cascade
        [HttpGet]
        public async Task<IActionResult> GetXaPhuongs(int tinhThanhId)
        {
            var xaList = await _context.XaPhuongs
                .Where(x => x.TinhThanhId == tinhThanhId)
                .OrderBy(x => x.TenXaPhuong)
                .Select(x => new { id = x.MaXaPhuong, name = x.TenXaPhuong })
                .ToListAsync();

            return Json(xaList);
        }

        public async Task<IActionResult> Index(string? searchString)
        {
            var query = _context.DiaDiems
                .Include(d => d.XaPhuong)
                    .ThenInclude(x => x!.TinhThanh)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                query = query.Where(d =>
                    d.MaDiaDiem.Contains(searchString) ||
                    d.TenDiaDiem.Contains(searchString) ||
                    (d.XaPhuong != null && d.XaPhuong.TenXaPhuong.Contains(searchString)) ||
                    (d.XaPhuong != null && d.XaPhuong.TinhThanh != null && d.XaPhuong.TinhThanh.TenTinh.Contains(searchString)));
            }

            var list = await query
                .OrderByDescending(d => d.ConSuDung)
                .ThenBy(d => d.TenDiaDiem)
                .ToListAsync();

            return View(list);
        }

        public async Task<IActionResult> Details(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var diaDiem = await _context.DiaDiems
                .Include(d => d.XaPhuong)
                    .ThenInclude(x => x!.TinhThanh)
                .FirstOrDefaultAsync(m => m.MaDiaDiem == id);

            if (diaDiem == null) return NotFound();
            return View(diaDiem);
        }

        public async Task<IActionResult> Create()
        {
            var model = new DiaDiem { MaDiaDiem = MaSoHelper.TaoMa("MDD"), ConSuDung = true };

            LoadTinhDropdown();
            await LoadXaDropdownAsync(null);

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(DiaDiem diaDiem, int? TinhThanhId)
        {
            if (string.IsNullOrWhiteSpace(diaDiem.MaDiaDiem))
                diaDiem.MaDiaDiem = MaSoHelper.TaoMa("MDD");

            if (!TinhThanhId.HasValue)
                ModelState.AddModelError("TinhThanhId", "Vui lòng chọn Tỉnh/Thành.");

            if (TinhThanhId.HasValue)
            {
                var xa = await _context.XaPhuongs.AsNoTracking()
                    .FirstOrDefaultAsync(x => x.MaXaPhuong == diaDiem.XaPhuongId);

                if (xa == null)
                    ModelState.AddModelError(nameof(DiaDiem.XaPhuongId), "Xã/Phường không hợp lệ.");
                else if (xa.TinhThanhId != TinhThanhId.Value)
                    ModelState.AddModelError(nameof(DiaDiem.XaPhuongId), "Xã/Phường không thuộc Tỉnh/Thành đã chọn.");
            }

            if (ModelState.IsValid)
            {
                if (_context.DiaDiems.Any(e => e.MaDiaDiem == diaDiem.MaDiaDiem))
                {
                    ModelState.AddModelError(nameof(DiaDiem.MaDiaDiem), "Mã địa điểm này đã tồn tại.");
                }
                else
                {
                    _context.Add(diaDiem);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
            }

            LoadTinhDropdown(TinhThanhId);
            await LoadXaDropdownAsync(TinhThanhId, diaDiem.XaPhuongId);
            ViewBag.SelectedTinhThanhId = TinhThanhId;

            return View(diaDiem);
        }

        public async Task<IActionResult> Edit(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var diaDiem = await _context.DiaDiems
                .Include(d => d.XaPhuong)
                    .ThenInclude(x => x!.TinhThanh)
                .FirstOrDefaultAsync(d => d.MaDiaDiem == id);

            if (diaDiem == null) return NotFound();

            var tinhId = diaDiem.XaPhuong?.TinhThanhId;

            LoadTinhDropdown(tinhId);
            await LoadXaDropdownAsync(tinhId, diaDiem.XaPhuongId);

            ViewBag.SelectedTinhThanhId = tinhId;

            return View(diaDiem);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, DiaDiem diaDiem, int? TinhThanhId)
        {
            if (id != diaDiem.MaDiaDiem) return NotFound();

            if (!TinhThanhId.HasValue)
                ModelState.AddModelError("TinhThanhId", "Vui lòng chọn Tỉnh/Thành.");

            if (TinhThanhId.HasValue)
            {
                var xa = await _context.XaPhuongs.AsNoTracking()
                    .FirstOrDefaultAsync(x => x.MaXaPhuong == diaDiem.XaPhuongId);

                if (xa == null)
                    ModelState.AddModelError(nameof(DiaDiem.XaPhuongId), "Xã/Phường không hợp lệ.");
                else if (xa.TinhThanhId != TinhThanhId.Value)
                    ModelState.AddModelError(nameof(DiaDiem.XaPhuongId), "Xã/Phường không thuộc Tỉnh/Thành đã chọn.");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(diaDiem);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.DiaDiems.Any(e => e.MaDiaDiem == diaDiem.MaDiaDiem)) return NotFound();
                    throw;
                }
            }

            LoadTinhDropdown(TinhThanhId);
            await LoadXaDropdownAsync(TinhThanhId, diaDiem.XaPhuongId);
            ViewBag.SelectedTinhThanhId = TinhThanhId;

            return View(diaDiem);
        }

        public async Task<IActionResult> Delete(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var diaDiem = await _context.DiaDiems
                .Include(d => d.XaPhuong)
                    .ThenInclude(x => x!.TinhThanh)
                .FirstOrDefaultAsync(m => m.MaDiaDiem == id);

            if (diaDiem == null) return NotFound();
            return View(diaDiem);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var diaDiem = await _context.DiaDiems.FindAsync(id);
            if (diaDiem != null)
            {
                _context.DiaDiems.Remove(diaDiem);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}

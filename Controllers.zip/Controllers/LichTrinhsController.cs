﻿// Folder: Controllers
// File path: Controllers/LichTrinhsController.cs

using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tour_2040.Data;
using Tour_2040.Models;

namespace Tour_2040.Controllers
{
    [Authorize]
    public class LichTrinhsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public LichTrinhsController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        private bool IsAdminOrStaff =>
            User.Identity != null &&
            User.Identity.IsAuthenticated &&
            (User.IsInRole("Admin") || User.IsInRole("Staff"));

        public async Task<IActionResult> Index(string? keyword, string? status, DateTime? fromDate, DateTime? toDate)
        {
            if (IsAdminOrStaff)
            {
                var query = _context.Tours.AsQueryable();

                if (!string.IsNullOrWhiteSpace(keyword))
                {
                    keyword = keyword.Trim().ToLower();
                    query = query.Where(t => t.TenTour.ToLower().Contains(keyword) || t.MaTour.ToLower().Contains(keyword));
                }

                if (fromDate.HasValue) query = query.Where(t => t.NgayDi >= fromDate.Value);
                if (toDate.HasValue) query = query.Where(t => t.NgayDi <= toDate.Value);

                var today = DateTime.Now.Date;
                if (!string.IsNullOrEmpty(status))
                {
                    switch (status)
                    {
                        case "Running":
                            query = query.Where(t => t.NgayDi <= today && t.NgayVe >= today);
                            break;
                        case "Upcoming":
                            query = query.Where(t => t.NgayDi > today);
                            break;
                        case "Completed":
                            query = query.Where(t => t.NgayVe < today);
                            break;
                    }
                }

                query = query.OrderBy(t => t.NgayDi);

                ViewData["Keyword"] = keyword;
                ViewData["Status"] = status ?? "All";
                ViewData["FromDate"] = fromDate?.ToString("yyyy-MM-dd");
                ViewData["ToDate"] = toDate?.ToString("yyyy-MM-dd");

                return View("AdminIndex", await query.ToListAsync());
            }
            else
            {
                var userId = _userManager.GetUserId(User);
                var query = _context.LichTrinhs
                    .Include(l => l.Tour)
                    .Include(l => l.User)
                    .Where(l => l.UserId == userId)
                    .OrderByDescending(l => l.NgayDat);

                return View(await query.ToListAsync());
            }
        }

        public async Task<IActionResult> AdminDetails(string id)
        {
            if (!IsAdminOrStaff) return Forbid();
            if (string.IsNullOrEmpty(id)) return NotFound();

            var tour = await _context.Tours
                .Include(t => t.TourDichVus).ThenInclude(td => td.DichVu)
                .Include(t => t.GiaoDiches).ThenInclude(g => g.User)
                .Include(t => t.GiaoDiches).ThenInclude(g => g.KhachHang)
                .FirstOrDefaultAsync(t => t.MaTour == id);

            if (tour == null) return NotFound();

            ViewBag.TotalBookings = tour.GiaoDiches.Count();
            ViewBag.TotalPax = tour.GiaoDiches.Sum(g => g.SoNguoiLon + g.SoTreEm);
            ViewBag.TotalRevenue = tour.GiaoDiches
                .Where(g => g.TrangThai != "Huy")
                .Sum(g => g.TongTien);

            return View(tour);
        }

        // ✅ FIX: Timeline đúng thực tế theo NgayThu + Gio
        public async Task<IActionResult> Details(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var lichTrinh = await _context.LichTrinhs
                .Include(l => l.Tour)
                    .ThenInclude(t => t.TourDichVus)
                        .ThenInclude(td => td.DichVu)
                .Include(l => l.User)
                .Include(l => l.LichTrinhChiTiets)
                    .ThenInclude(m => m.DiaDiem)
                .Include(l => l.LichTrinhChiTiets)
                    .ThenInclude(m => m.DichVuKemTheo)
                        .ThenInclude(x => x.DichVu)
                .FirstOrDefaultAsync(l => l.MaLichTrinh == id);

            if (lichTrinh == null) return NotFound();

            // Security
            if (!IsAdminOrStaff)
            {
                var userId = _userManager.GetUserId(User);
                if (lichTrinh.UserId != userId) return Forbid();
            }

            var now = DateTime.Now;
            var ngayDi = lichTrinh.Tour?.NgayDi?.Date;

            // Nếu thiếu NgayThu ở data cũ -> coi như ngày 1
            foreach (var m in lichTrinh.LichTrinhChiTiets)
            {
                if (m.NgayThu <= 0) m.NgayThu = 1;
            }

            if (ngayDi.HasValue && lichTrinh.LichTrinhChiTiets.Any())
            {
                var mocWithTime = lichTrinh.LichTrinhChiTiets
                    .Select(m => new
                    {
                        Moc = m,
                        Time = ngayDi.Value.AddDays(m.NgayThu - 1).Add(m.Gio)
                    })
                    .OrderBy(x => x.Time)
                    .ToList();

                var current = mocWithTime
                    .Where(x => x.Time <= now)
                    .OrderByDescending(x => x.Time)
                    .FirstOrDefault();

                ViewBag.BuocHienTaiId = current?.Moc.MaLichTrinhChiTiet;

                // Cho view dùng
                ViewBag.NgayKhoiHanh = ngayDi.Value;
                ViewBag.Now = now;

                // Update sorted list
                lichTrinh.LichTrinhChiTiets = mocWithTime.Select(x => x.Moc).ToList();
            }

            return View(lichTrinh);
        }
    }
}

﻿// Folder: Data
// File path: Data/SeedData.cs

using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;
using Tour_2040.Models;

namespace Tour_2040.Data
{
    public static class SeedData
    {
        public static async Task InitializeAsync(IServiceProvider services)
        {
            using var scope = services.CreateScope();

            // 1. Lấy DbContext để đảm bảo Database đã được cập nhật Migration
            var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

            // Lệnh này cực kỳ quan trọng: Nó sẽ tự động chạy "Update-Database" bằng code
            // Giúp bạn không bị lỗi "Table not found" khi chạy lần đầu
            await context.Database.MigrateAsync();

            // 2. Lấy các Service quản lý User và Role
            var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

            // 3. Tạo Roles (Quyền truy cập)
            string[] roles = { "Admin", "Staff", "User" };

            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    await roleManager.CreateAsync(new IdentityRole(role));
                }
            }

            // 4. Tạo tài khoản ADMIN mặc định (nếu chưa có)
            await CreateUserIfNotExists(userManager,
                email: "admin@tour2040.com",
                password: "Admin@123", // Mật khẩu cần có: Hoa, thường, số, ký tự đặc biệt
                role: "Admin",
                hoTen: "Quản Trị Viên",
                maNguoiDung: "ADMIN01");

            // Bạn có thể thêm code tạo Staff hoặc User mẫu ở đây nếu muốn
        }

        private static async Task CreateUserIfNotExists(
            UserManager<ApplicationUser> userManager,
            string email,
            string password,
            string role,
            string hoTen,
            string maNguoiDung)
        {
            var user = await userManager.FindByEmailAsync(email);

            if (user == null)
            {
                user = new ApplicationUser
                {
                    UserName = email,
                    Email = email,
                    EmailConfirmed = true, // Xác thực email luôn để đăng nhập được ngay
                    HoTen = hoTen,
                    MaNguoiDung = maNguoiDung,
                    NgaySinh = DateTime.Now,
                    ProfilePictureUrl = null
                };

                var result = await userManager.CreateAsync(user, password);

                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(user, role);
                }
            }
        }
    }
}